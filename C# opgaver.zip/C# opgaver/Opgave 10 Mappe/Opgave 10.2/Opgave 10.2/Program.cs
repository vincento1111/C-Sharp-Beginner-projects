﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Opgave_10._2
{
    class Program
    {
        static void Main(string[] args)
        {

            Console.Write("Indtast din alder: ");
            int alder = Convert.ToInt32(Console.ReadLine()); //Laver en string om til et tal
            

            if (alder > 57)
            {
                Console.WriteLine("Du er for gammel");
            }
            else
            {
                Console.WriteLine("Du er ikke for gammel");
            }

        }
    }
}
