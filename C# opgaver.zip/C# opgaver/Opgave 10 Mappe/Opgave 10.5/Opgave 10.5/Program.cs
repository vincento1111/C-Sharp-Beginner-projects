﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Opgave_10._5
{
    class Program
    {
        static void Main(string[] args)
        {

            Console.WriteLine("Indtast dit navn");
            string navn = Console.ReadLine();
            Console.WriteLine("Indtast dit brugernavn");
            string brugernavn = Console.ReadLine();
            Console.WriteLine("Indtast Password");
            string password = Console.ReadLine();

            string realPass = "1234";

            string realBruger = "vincent";

            if (brugernavn == realBruger)

            {
                if (password == realPass)
                {
                    Console.WriteLine("Velkommen {0}", navn);
                }
                else
                {
                    Console.WriteLine("Password er forkert");
                }
            }
            else
            {
                Console.WriteLine("password er forkert");
            }

        }
    }
}
