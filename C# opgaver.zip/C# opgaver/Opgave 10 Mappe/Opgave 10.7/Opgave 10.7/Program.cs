﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Opgave_10._7
{
    class Program
    {
        static void Main(string[] args)
        {
            Console.WriteLine("Indtast et tal mellem 1 til 6");
            int tal = Convert.ToInt32(Console.ReadLine());
            Console.WriteLine("Vil du have rød, gul, grøn eller blue baggrundsfarve");
            string farve = Console.ReadLine().ToLower();
            


            if (6 >= tal && 1 <= tal && tal != 4) //hvis tallet er 1,2,3,5 eller 6 og ikke 4
            {

                Console.WriteLine("Du har tastet ", tal, "tallet" );
                // "du har tastet x"
            }
            else if (tal == 4)
            {
                if (farve == "rød") // laver bagrundsfarven om til den brugeren valgte
                {
                    Console.BackgroundColor = ConsoleColor.Red;
                }
                else if (farve == "gul")
                {
                    Console.BackgroundColor = ConsoleColor.Yellow;
                }
                else if (farve == "grøn")
                {
                    Console.BackgroundColor = ConsoleColor.Green;
                }
                else
                {
                    Console.BackgroundColor = ConsoleColor.Blue;
                }
                Console.SetCursorPosition(50, 20);
                Console.WriteLine("TILLYKKE DU HAR VUNDET");
                // "du har vundet" + bagrundsfarve
            }
            else
            {
                Console.WriteLine("Du har tastet forkert. tallet skal være mellem 1 og 6");
                //programmet skal lukke
                System.Threading.Thread.Sleep(10000);
            }
        }
    }
}
