﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Opgave_10._1
{
    class Program
    {
        static void Main(string[] args)
        {

            int tal1 = 42;
            int tal2 = 64;
            int result = tal1 + tal2;
            if(result > 100) //hvis result er større end 100
            {
                Console.WriteLine("Summen er strørre end 100!");
            }
            else if (result < 100) //Hvis den er under 100
            {
                Console.WriteLine("Summen er mindre end 100");
            }
            else //Hvis den er 100
            {
                Console.WriteLine("Summen er 100");
            }

        }
    }
}
