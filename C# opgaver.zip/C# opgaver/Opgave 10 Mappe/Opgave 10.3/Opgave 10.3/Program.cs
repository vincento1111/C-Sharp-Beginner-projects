﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Opgave_10._3
{
    class Program
    {
        static void Main(string[] args)
        {



            Console.Write("Indtast din alder: ");
            int alder = Convert.ToInt32(Console.ReadLine());


            if (alder > 60)
            {
                Console.WriteLine("Du er for gammel");
            }
            else if(alder > 49 && alder < 60) //hvis alder er OVER 49 OG under 60
            {
                Console.WriteLine("Du er hverken for gammel eller for ung");
            }
            else
            {
                Console.WriteLine("Du er for ung");
            }





        }
    }
}
