﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Opgave_10._6
{
    class Program
    {
        static void Main(string[] args)
        {

            Console.WriteLine("Hvor mange km kører du til or fra arbejde?");

            double km = Convert.ToDouble(Console.ReadLine());

            if (km  > 24 && km < 121)
            {
                double fradrag = (km - 24) * 1.93;
                Console.WriteLine("{0}", fradrag);
            }
            else if(km > 121)
            {
                double fradrag = 96 * 1.93 + (km - 120) * 0.97;
                Console.WriteLine("{0}", fradrag  );
            }
            else
            {
                Console.WriteLine("Du får ikke noget fradrag");
            }


        }
    }
}
