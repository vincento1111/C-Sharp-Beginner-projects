﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Opgave_12._1
{
    class Program
    {
        static void Main(string[] args)
        {
            int x = 0;
            int i = 0;
            for ( i = 0; i < 100;) //for loop med I værdi
            {
                i++;
                Console.WriteLine(i);
            }
            while (x < 100) // While loop med X værdi
            {
                x++;
                Console.WriteLine(x);
            }

        }
    }
}
