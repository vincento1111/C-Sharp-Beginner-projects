﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Opgave_12._4
{
    class Program
    {
        static void Main(string[] args)
        {

            int x = 20;

            for (int i = 20; i > 1;) //for loop med I værdi
            {
                i--; //I bliver mindre med 1 hver gang looped køre
                Console.WriteLine(i);
            }
            while (x > 1) // While loop med X værdi
            {
                x--; //X bliver mindre med 1 hver gang looped køre
                Console.WriteLine(x);
            }

        }
    }
}
