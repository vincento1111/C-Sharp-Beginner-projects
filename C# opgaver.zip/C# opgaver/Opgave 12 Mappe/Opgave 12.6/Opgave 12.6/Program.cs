﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Opgave_12._6
{
    class Program
    {
        static void Main(string[] args)
        {
            int tabel = Convert.ToInt32(Console.ReadLine());
            for (int i = 1; i <= 10; i++)
            {
                Console.WriteLine("{0} * {2} = {1}",
                    i, 
                    i * tabel,
                    tabel); // tabel/bruger input * 1,2,3,4, etc
            }

        }
    }
}
