﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Opgave_10._5
{
    class Program
    {
        static void Main(string[] args)
        {

            for (int i = 0; i <= 10; i++)
            {
                Console.WriteLine("{0} * 7 = {1}", i, i * 7); // tallet som 7 bliver ganget med gå op med 1 per loop
            }
        }
    }
}
