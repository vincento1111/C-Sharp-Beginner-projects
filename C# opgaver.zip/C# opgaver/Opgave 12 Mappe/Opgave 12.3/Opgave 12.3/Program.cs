﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Opgave_12._3
{
    class Program
    {
        static void Main(string[] args)
        {
            for (int i = 0; i <= 50; i = i + 5) //så længe I er mindre end 5, bliver i 5 større
            {
                Console.WriteLine(i);
            }
            
        }
    }
}
