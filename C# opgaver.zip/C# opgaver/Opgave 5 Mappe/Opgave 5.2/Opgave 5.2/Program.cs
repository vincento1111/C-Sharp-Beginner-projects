﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Opgave_5._2
{
    class Program
    {
        static void Main(string[] args)
        {

            string ord = "lul";
            int tal = 666;
            double decimalTal = 9.11;
            ord = "hehe xd"; //Værdierne bliver ændret
            tal = 420;
            decimalTal = 7.11;

            Console.WriteLine("{0}\n{1}\n{2}", ord, tal, decimalTal);

        }
    }
}
