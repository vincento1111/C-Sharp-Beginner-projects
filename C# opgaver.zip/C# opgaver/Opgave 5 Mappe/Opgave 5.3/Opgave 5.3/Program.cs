﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Opgave_5._3
{
    class Program
    {
        static void Main(string[] args)
        {
            string lolwut = "I dag har vi den 8. november";
            Console.WriteLine(lolwut);
        }
    }
}
