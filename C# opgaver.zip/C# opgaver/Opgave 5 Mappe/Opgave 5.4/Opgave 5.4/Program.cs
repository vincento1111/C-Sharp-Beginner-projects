﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Opgave_5._4
{
    class Program
    {
        static void Main(string[] args)
        {

            double minePenge = 200.50;
            string xHar = "Jeg har ";
            string xKroner = " kr. i banken";
            Console.WriteLine("{0}{1}{2}", xHar, minePenge, xKroner );



        }
    }
}
