﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Opgave_5
{
    class Program
    {
        static void Main(string[] args)
        {
            Console.CursorVisible = false; //Gør cursoren usynlig
            int i = 9;
            Console.SetCursorPosition(5,i++); //ændre position på cursoren
            Console.ForegroundColor = ConsoleColor.Green; 
            Console.WriteLine("Grøn");
            Console.SetCursorPosition(5, i++); 

            Console.ForegroundColor = ConsoleColor.Yellow;
            Console.WriteLine("Gul");
            Console.SetCursorPosition(5, i++);

            Console.ForegroundColor = ConsoleColor.Blue;
            Console.WriteLine("Blå");
            Console.SetCursorPosition(5, i++);

            Console.ForegroundColor = ConsoleColor.White;
            Console.WriteLine("Hvid");


            Console.ReadKey();
        }
    }
}
