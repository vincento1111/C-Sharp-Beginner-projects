﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Opgave_6
{
    class Program
    {
        static void Main(string[] args)
        {
            int i = 9;
            Console.ForegroundColor = ConsoleColor.Green;
            Console.BackgroundColor = ConsoleColor.White;
            Console.SetCursorPosition(5, i++);
            String navn = "Vincent"; //Laver en string med navnet vincent
            Console.WriteLine(navn);

            Console.ForegroundColor = ConsoleColor.Blue;
            Console.BackgroundColor = ConsoleColor.Green;
            String Adresse = "Stolpehøj 116";
            Console.SetCursorPosition(5, i++);
            Console.WriteLine(Adresse);

            Console.ForegroundColor = ConsoleColor.Gray;
            Console.BackgroundColor = ConsoleColor.Red;
            String Tlfnr = "31143143";
            Console.SetCursorPosition(5, i++);
            Console.WriteLine(Tlfnr);

            Console.ReadKey();
        }
    }
}
