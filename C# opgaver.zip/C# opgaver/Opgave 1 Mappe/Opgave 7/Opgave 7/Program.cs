﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Opgave_7
{
    class Program
    {
        static void Main(string[] args)
        {
            //Opgave 1

            Console.WriteLine("jeg glæder mig til C#?");
            Console.ReadKey();


            //Opgave 2

            Console.ForegroundColor = ConsoleColor.Red;

            Console.WriteLine("jeg glæder mig til c#");
            Console.ReadKey();


            //Opgave 3

            Console.BackgroundColor = ConsoleColor.Yellow;
            Console.ForegroundColor = ConsoleColor.Blue;
            Console.WriteLine("Jeg glæder mig så fucking meget til C# WOOOOOOOOOOOOOP!");
            Console.ReadKey();


            //Opgave 4

            Console.BackgroundColor = ConsoleColor.Gray;
            Console.ForegroundColor = ConsoleColor.Green;
            Console.SetCursorPosition(30, 4);
            Console.WriteLine("Jeg glæder mig super meget til C#");
            Console.ReadKey();

            //Opgave 5
            Console.CursorVisible = false;
            int i = 9;
            Console.SetCursorPosition(5, i++);
            Console.ForegroundColor = ConsoleColor.Green;
            Console.WriteLine("Grøn");
            Console.SetCursorPosition(5, i++);

            Console.ForegroundColor = ConsoleColor.Yellow;
            Console.WriteLine("Gul");
            Console.SetCursorPosition(5, i++);

            Console.ForegroundColor = ConsoleColor.Blue;
            Console.WriteLine("Blå");
            Console.SetCursorPosition(5, i++);

            Console.ForegroundColor = ConsoleColor.White;
            Console.WriteLine("Hvid");


            Console.ReadKey();


            //Opgave 6

            
            Console.ForegroundColor = ConsoleColor.Green;
            Console.BackgroundColor = ConsoleColor.White;
            Console.SetCursorPosition(5, i++);
            String navn = "Vincent";
            Console.WriteLine(navn);

            Console.ForegroundColor = ConsoleColor.Blue;
            Console.BackgroundColor = ConsoleColor.Green;
            String Adresse = "Stolpehøj 116";
            Console.SetCursorPosition(5, i++);
            Console.WriteLine(Adresse);

            Console.ForegroundColor = ConsoleColor.Gray;
            Console.BackgroundColor = ConsoleColor.Red;
            String Tlfnr = "31143143";
            Console.SetCursorPosition(5, i++);
            Console.WriteLine(Tlfnr);

            Console.ReadKey();
        }
    }
}
