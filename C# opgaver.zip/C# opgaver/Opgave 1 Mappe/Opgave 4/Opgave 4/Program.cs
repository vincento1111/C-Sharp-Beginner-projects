﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Opgave_4
{
    class Program
    {
        static void Main(string[] args)
        {
            Console.BackgroundColor = ConsoleColor.Gray;
            Console.ForegroundColor = ConsoleColor.Green;
            Console.SetCursorPosition(30,4); //Sætter cursor positionen
            Console.WriteLine("Jeg glæder mig super meget til C#");
            Console.ReadKey();
           
        }
    }
}
