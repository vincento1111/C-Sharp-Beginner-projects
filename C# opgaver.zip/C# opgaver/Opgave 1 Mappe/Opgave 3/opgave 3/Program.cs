﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace opgave_3
{
    class Program
    {
        static void Main(string[] args)
        {
            Console.BackgroundColor = ConsoleColor.Yellow; //Skifter bagrundsfarve
            Console.ForegroundColor = ConsoleColor.Blue;
            Console.WriteLine("Jeg glæder mig så fucking meget til C# WOOOOOOOOOOOOOP!");
            Console.ReadKey();
        }
    }
}
