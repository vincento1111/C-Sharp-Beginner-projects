﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Opgave_2
{
    class Program
    {
        static void Main(string[] args)
        {
            Console.ForegroundColor = ConsoleColor.Red; //ændre forgrunden

            Console.WriteLine("jeg glæder mig til c#"); //udskriver tekst
            Console.ReadKey();
        }
    }
}
