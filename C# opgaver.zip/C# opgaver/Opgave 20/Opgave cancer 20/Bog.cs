﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Opgave_cancer_20
{
    class Bog
    {
        public int pris;
        public String title;
        public Bog(int pris, String title) //Sætter værdierne på Bog
        {
            this.pris = pris;
            this.title = title;
        }
        


        public void PrintInfo() // Jeg bruger til at kalde udskriften
        {
            Console.WriteLine("[Bog] - " + title + " - " + pris + "Kr"); 
        }


    }
}
