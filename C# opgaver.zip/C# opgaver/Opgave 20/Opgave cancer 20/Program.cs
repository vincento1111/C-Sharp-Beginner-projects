﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Opgave_cancer_20
{
    class Program
    {
        static void Main(string[] args)
        {

            Bog sherlockHolmes = new Bog(50, "Jeg er en bog"); // Sætter bogens pris og tittel
            Bog2 swag = new Bog2("Super Ok"); // Sætter bogens Tittel
            sherlockHolmes.PrintInfo(); //Udskriver Information fra bog klassen
            swag.PrintInfo(); // Udskriver information fra bog2 
        }
    }
}
