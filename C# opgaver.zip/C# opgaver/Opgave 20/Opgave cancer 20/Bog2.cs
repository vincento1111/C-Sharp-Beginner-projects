﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Opgave_cancer_20
{
    class Bog2
    {

        public String title;
        public Bog2( String title) //Sætter værdierne på Bog2
        {
            
            this.title = title;
        }



        public void PrintInfo()
        {
            Console.WriteLine("[Bog2] - " + title + " - " + "Kr");
        }

    }
}
