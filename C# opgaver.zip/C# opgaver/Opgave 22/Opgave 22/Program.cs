﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Opgave_22
{
    class Program
    {
        static void Main(string[] args)
        {
            int sum = 0;
            int[] tal = { 420, 69, 911, 666, 27, 0 }; //laver mit array

            for (int i = 0; i < tal.Length; i++) //loopet køre 1 gang for hver enkelt værdi i mit array
            {
                sum = sum + tal[i]; // udregner sum
                
            }
            Console.WriteLine(sum);

            String[] balanced = { "Black ", "Gohan ", "Cell ", "Hit ", "16 " };

            for (int i = 0; i < balanced.Length; i++)
            {
                Console.WriteLine(balanced[i]); //Udskriver en string fra array
            }
        }
    }
}
