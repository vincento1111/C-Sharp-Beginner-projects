﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Opgave_2._2
{
    class Program
    {
        static void Main(string[] args)
        {
            string m = "Hello World";
            Console.BackgroundColor = ConsoleColor.Blue;
            Console.ForegroundColor = ConsoleColor.White;
            Console.SetCursorPosition(Console.WindowWidth / 2 - m.Length,Console.WindowHeight / 2); //Sætter teksten i midten af programmet
            Console.WriteLine(m);

            Console.ReadKey();


        }
    }
}
