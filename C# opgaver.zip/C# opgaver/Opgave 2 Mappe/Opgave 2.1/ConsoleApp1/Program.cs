﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ConsoleApp1
{
    class Program
    {
        static void Main(string[] args)
        {

            /*
             Kommentare
             FLERE LINJER
               */
            // KUN EN LINJE 
            Console.WriteLine("Jeg er");
            Console.Write("elev på");
            Console.Write("TEC i");
            Console.WriteLine("Lyngby"); //Faktisk var det Frederiksberg

            //  virker ikke fordi write og writeline ikke bliver brugt rigtigt
            Console.ReadKey();
        }
    }
}
