﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Opgave_17
{
    class Program
    {
        static void Main(string[] args)
        {

            Bog sherlockHolmes = new Bog();
            sherlockHolmes.SetPenge(500);
            int penge = sherlockHolmes.GetPenge();
            
            sherlockHolmes.SetPris(240);
            sherlockHolmes.SetTitle("Moby Dick");
            sherlockHolmes.Harråd(penge);
            sherlockHolmes.PrintInfo();
            
        }
    }
}
