﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Opgave_19._1
{
    class Chair : Furniture_class
    {

        private double kilo;

        public void SetKilo(double kilo)
        {
            this.kilo = kilo;
        }

        public double GetKilo()
        {
            return kilo;
        }



        public void PrintInfo()
        {
            Console.WriteLine("[Chair] " + manufacturer + " - " + cost + " - " + kilo + " kilo");
        }

    }
}
