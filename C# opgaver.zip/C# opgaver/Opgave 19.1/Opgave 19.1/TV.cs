﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Opgave_19._1
{
    class TV : Furniture_class
    {
        private int inches;

        public void SetInches(int inches)
        {
            this.inches = inches;
        }

        public int GetInches()
        {
            return inches;
        }

        public void PrintInfo()
        {
            Console.WriteLine("[TV] " + manufacturer + " - " + cost + " - " + inches + " tommer");
        }
    }
}
