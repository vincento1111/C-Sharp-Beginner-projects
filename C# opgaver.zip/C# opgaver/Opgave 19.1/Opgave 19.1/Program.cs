﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Opgave_19._1
{
    class Program
    {
        static void Main(string[] args) 
        {
            TV f = new TV();
            Chair c = new Chair();
            Computer cpu = new Computer();
            f.SetCost(150.45);
            c.SetCost(400);
            f.SetManufacturer("samsung");
            c.SetManufacturer("Ikea");
            f.SetInches(50);
            f.PrintInfo();
            c.SetKilo(2.5);
            c.PrintInfo();
            cpu.SetManufacturer("IBM");
            cpu.SetRam(8);
            cpu.SetCost(500);
            cpu.PrintInfo();


        }
    }
}
