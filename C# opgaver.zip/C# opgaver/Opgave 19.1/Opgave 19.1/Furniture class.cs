﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Opgave_19._1
{
    class Furniture_class //hovedklassen
    {

        protected double cost;
        protected String manufacturer;

        public void SetCost(double cost)
        {
            this.cost = cost;
        }

        public double GetCost()
        {
            return cost;
        }

        public void SetManufacturer(String manufacturer)
        {
            this.manufacturer = manufacturer;
        }

        public void PrintInfo()
        {
            Console.WriteLine("[Furniture] " + manufacturer + " - " + cost );
        }
    }
}
