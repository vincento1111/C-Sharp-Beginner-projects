﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Opgave_19._1
{
    class Computer : Chair 
    {

        private double ram;

        public void SetRam(double ram)
        {
            this.ram = ram;
        }

        public double GetRam()
        {
            return ram;
        }



        public void PrintInfo()
        {
            Console.WriteLine("[Computer] " + manufacturer + " - " + cost + " - " + ram + "GB Ram");



        }
    }
}
