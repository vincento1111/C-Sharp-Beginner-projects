﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Opgave_8._2
{
    class Program
    {
        static void Main(string[] args)
        {

            int tæller1 = 0;
            int tæller2 = 0;
            while(tæller1 < 5 || tæller2 > 5) //mens tæller2 er mindre end 5 eller tæller2 
            {
               
                Console.WriteLine("{0}, Tæller1", tæller1++); //udskriver tæller1 og forøger med 1
                Console.WriteLine("{0}, Tæller2", ++tæller2); //forøger tæller2 med 1 og udskriver
            }

        }
    }
}
