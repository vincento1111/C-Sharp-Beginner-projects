﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Opgave_8._1
{
    class Program
    {
        static void Main(string[] args)
        {

            int tæller = 0;

            while(tæller < 5) // så længe tæller er mindre end 5 kører loopet
            {
                Console.WriteLine(tæller);
                tæller++; // tæller bliver 1 større
            }
            Console.WriteLine(tæller);
        }
    }
}
