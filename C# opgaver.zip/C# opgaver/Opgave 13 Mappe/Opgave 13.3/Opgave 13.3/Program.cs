﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Opgave_13._3
{
    class Program
    {
        static void Main(string[] args)
        {

            Console.WriteLine("Hvor mange km kører du til or fra arbejde?");

            double km = Convert.ToDouble(Console.ReadLine()); //String til double

            if (km > 24 && km <= 100)
            {
                double fradrag = (km - 24) * 1.54;
                Console.WriteLine("{0}", fradrag + "Kr");
            }
            else if (km > 100)
            {
                double fradrag = 96 * 1.54 + (km - 100) * 0.77;
                Console.WriteLine("{0}", fradrag + "Kr");
            }
            else
            {
                Console.WriteLine("Du får ikke noget fradrag");
            }

        }
    }
}
