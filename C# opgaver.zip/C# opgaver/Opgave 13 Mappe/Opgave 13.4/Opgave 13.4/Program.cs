﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Opgave_13._4
{
    class Program
    {
        static void Main(string[] args)
        {
            Console.WriteLine("Indtast venligst din årsindtægt");
            double løn = Convert.ToInt32(Console.ReadLine());
            double lønFørSkat = løn;
            if (løn <= 42000)
            {
                Console.WriteLine("Du skal ikke betale skat");
            }

            else if (løn > 42000 && løn <= 280000)
            {
                
                løn = løn * 70 / 100;
                

                Console.WriteLine("Du betaler {0} i skat. sådan beregner vi. {1} * 30 / 100", lønFørSkat * 30 / 100, lønFørSkat);
                Console.WriteLine("Du har {0} efter bundskat: {1} * 70 / 100 = {2}", løn, lønFørSkat,løn);
            }
            else if (løn >280000 && løn <= 390000)
            {
                løn = løn * 64 / 100;
                Console.WriteLine("Du betaler {0} i skat. sådan beregner vi. {1} * 36 / 100", lønFørSkat * 36 / 100, lønFørSkat);
                Console.WriteLine("Du har {0} efter mellemskat: {1} * 64 / 100 = {2}", løn, lønFørSkat,løn);
            }
            else if (løn > 390000)
            {
                løn = løn * 55 / 100;
                Console.WriteLine("Du betaler {0} i skat. sådan beregner vi. {1} * 45 / 100", lønFørSkat * 45 / 100, lønFørSkat);
                Console.WriteLine("Du har {0} efter topskat: {1} * 55 / 100 = {2}", løn, lønFørSkat,løn);
            }
            else
            {
                Console.WriteLine("how the....");
            }

        }
    }
}
