﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Opgave_13._2
{
    class Program
    {
        static void Main(string[] args)
        {

            for (int i = 1; i <= 10; i++)
            {
                Console.WriteLine("{0} * 4 = {1}", i, i * 4); // tallet som 7 bliver ganget med gå op med 1 per loop
                if (i * 4 == 16)
                {

                    i++;

                }
            }
            Console.WriteLine("Loppen er nu stoppet");
        }
    }
}
