﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Opgave_13._1._1
{
    class Program
    {
        static void Main(string[] args)
        {


            for (int i = 1; i <= 10; i++) //så længe i er mindre end 10 
            {
                Console.WriteLine("{0} * 3 = {1}", i, i * 3); // tallet som 7 bliver ganget med gå op med 1 per loop
                if (i * 3 == 21)
                {
                    Console.WriteLine("Loppen er nu stoppet");
                    break; //afbryder for loop

                }
            }

        }
    }
}
