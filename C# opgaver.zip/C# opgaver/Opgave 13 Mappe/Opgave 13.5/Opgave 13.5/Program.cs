﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Opgave_13._5
{
    class Program
    {
        static void Main(string[] args)
        {

            Console.WriteLine("Hvor mange penge har du på din konto?");
            int konto = Convert.ToInt32(Console.ReadLine());
            double rente = 0;
            double rentesats = 0;
            if (konto <= 25000)
            {
                rentesats = 0.25;
                rente = rentesats * konto / 100;
                Console.WriteLine(rente);
                
            }
            else if(konto > 25000 && konto < 150000)
            {
                rentesats = 1.25;
                rente = rentesats * konto / 100;
                Console.WriteLine(rente);

            }
            else
            {
                rentesats = 1.25;
                rente = (150000 * rentesats / 100) + (konto - 150000) * 0.5 / 100;
                Console.WriteLine(rente);

            }
        }
    }
}
