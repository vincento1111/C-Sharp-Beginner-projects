﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Opgave_15_for_realz
{
    class Program
    {
        static void Main(string[] args)
        {

            Bog sherlockHolmes = new Bog(); //sherlockholmes = bog

            sherlockHolmes.PrintInfo(); //Kalder variabel fra bog
        }
    }
}
