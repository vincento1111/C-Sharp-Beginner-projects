﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Opgave_15_for_realz
{
    class Bog
    {
        public void PrintInfo()
        {
            Console.WriteLine("Jeg er en bog");
        }

        
    }
}
