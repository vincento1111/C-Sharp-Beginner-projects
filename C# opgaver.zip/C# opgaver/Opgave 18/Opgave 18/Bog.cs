﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Opgave_18
{
    class Bog : Person //bog nedarver fra person
    {

        public void PrintBookInfo()
        {
            Console.WriteLine(favoriteBook);
            Console.WriteLine(numberOfPages);
            Console.WriteLine(bookDescriptions + "\n");

        }
    }
}
