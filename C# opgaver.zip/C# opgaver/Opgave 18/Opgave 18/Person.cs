﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Opgave_18
{
    class Person
    {

        public int alder;
        public string navn;
        public double pengebeholdning;
        public string numberOfPages = "420 Sider";
        public string favoriteBook = "Ignorance is bliss";
        public string bookDescriptions = "Literally makes you superman when you read it!";
        public void SetAlder(int alder)
        {
            this.alder = alder;
        }
        public int GetAlder()
        {
            return alder;
        }


        public void SetNavn(String navn)
        {
            this.navn = navn;
        }
        public string Getnavn()
        {
            return navn;
        }


        public void SetPengebeholdning(double pengebeholdning)
        {
            this.pengebeholdning = pengebeholdning;
        }
        public double GetPengebeholdning()
        {
            return pengebeholdning;

        }
        public void SetFavoriteBook(string favoriteBook)
        {
            this.favoriteBook = favoriteBook;
        }
        public string GetFavoriteBook()
        {
            return favoriteBook;
        }

        public void PrintInfo()
        {
            Console.WriteLine(pengebeholdning);
            Console.WriteLine(navn);
            Console.WriteLine(alder);
        }
    }
}
