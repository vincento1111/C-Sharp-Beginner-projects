﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Opgave_18
{
    class Program
    {
        static void Main(string[] args)
        {
            Bog sherlockHolmes = new Bog();
            Person vincent = new Person();

            vincent.SetAlder(20);
            vincent.SetNavn("Vincent");
            vincent.SetPengebeholdning(1000);
            vincent.PrintInfo();
            sherlockHolmes.PrintBookInfo();
        }
    }
}
