﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Opgave_7._2
{
    class Program
    {
        static void Main(string[] args)
        {

            int tal1 = 69;
            int tal2 = 420;
            int tal3 = 42;
            double result = tal1 + 4543 - tal1 * 65 / tal2 % tal3;
            Console.WriteLine(result);


        }
    }
}
