﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Opgave_7._1
{
    class Program
    {
        static void Main(string[] args)
        {

            int tal1 = 69;
            int tal2 = 420;
            int tal3 = 42;
            double result = tal1 + tal2 - tal1 * tal3 / tal2 % tal2; // 69 + 420 - 69 * 42 / 420 % 420
            Console.WriteLine(result);
        }
    }
}
