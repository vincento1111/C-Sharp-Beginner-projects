﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Opgave_9._1
{
    class Program
    {
        static void Main(string[] args)
        {

            int var1 = 1;
            int var2 = 2;
            Boolean wtf = var1 > var2; //udsagn. var1 er større end var2
            Console.WriteLine(wtf); //False



        }
    }
}
