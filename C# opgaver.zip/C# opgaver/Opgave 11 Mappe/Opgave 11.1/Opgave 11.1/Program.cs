﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Opgave_11._1
{
    class Program
    {
        static void Main(string[] args)
        {
            Console.WriteLine("Indtast et tal mellem 1 til 6");
            int tal = Convert.ToInt32(Console.ReadLine()); //Bruger input
            Console.WriteLine("Vil du have rød, gul, grøn eller blue baggrundsfarve");
            string farve = Console.ReadLine().ToLower();

            switch (tal) 
            {
                case 1:
                case 2:
                case 3:
                case 5:
                case 6:


                    Console.WriteLine("Du har tastet " + tal + " tallet"); //hvis der bliver tastet 1 2 3 5 eller 6


                break;

                case 4: //hvis 4
                    if (farve == "rød") // laver bagrundsfarven om til den brugeren valgte
                    {
                        Console.BackgroundColor = ConsoleColor.Red;
                        Console.Clear();
                    }
                    else if (farve == "gul")
                    {
                        Console.BackgroundColor = ConsoleColor.Yellow;
                        Console.Clear();
                    }
                    else if (farve == "grøn")
                    {
                        Console.BackgroundColor = ConsoleColor.Green;
                        Console.Clear();
                    }
                    else
                    {
                        Console.BackgroundColor = ConsoleColor.Blue;
                        Console.Clear();
                    }
                    Console.SetCursorPosition(50, 20);
                    Console.WriteLine("TILLYKKE DU HAR VUNDET");
                    // "du har vundet" + bagrundsfarve
                    break;

                default:

                    Console.WriteLine("Du har tastet forkert. tallet skal være mellem 1 og 6");
                    //programmet skal lukke
                    System.Threading.Thread.Sleep(10000);
                    break;
            }



            
        }
    }
}
