﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Opgave_11._2
{
    class Program
    {
        static void Main(string[] args)
        {

            Console.WriteLine("1. Isbjørn 30Kr");

            Console.WriteLine("2. Champagnebrus 32Kr");

            Console.WriteLine("3. Tequila Sunrise 29Kr");

            Console.WriteLine("4. Mojito 25Kr");

            Console.WriteLine("5. Brandbil 27Kr");

            Console.WriteLine("6. Filur 28kr");

            Console.WriteLine("Vælg et nummer fra menuen.");
            int isbørn = 30;
            int champ = 32;
            int tequila = 29;
            int mojito = 25;
            int brand = 27;
            int filur = 28;
            int drink = Convert.ToInt32(Console.ReadLine());

            switch (drink){
                case 1:
                    Console.WriteLine("Du har valgt en Isbjørn for 30Kr");
                    break;

                case 2:
                    Console.WriteLine("Du har valgt en Champagnebrus for 32Kr");
                    break;
                case 3:
                    Console.WriteLine("Du har valgt en Tequila Sunrise for 29Kr");
                    break;
                case 4:
                    Console.WriteLine("Du har valgt en Mojito for 25Kr");
                    break;
                case 5:
                    Console.WriteLine("Du har valgt en Brandbil for 27Kr");
                    break;
                case 6:
                    Console.WriteLine("Du har valgt en Filur for 28Kr");
                    break;

            }

                

        }
    }
}
