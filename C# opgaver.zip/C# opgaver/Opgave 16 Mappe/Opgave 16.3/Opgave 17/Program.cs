﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Opgave_16
{
    class Program
    {
        static void Main(string[] args)
        {

            Bog sherlockHolmes = new Bog();
            sherlockHolmes.SetPenge(50); //Sætter pengebeholdning
            sherlockHolmes.SetPris(150); //pris
            int penge = sherlockHolmes.GetPenge();
            int pris = sherlockHolmes.GetPris();
            
            sherlockHolmes.SetTitle("Moby Dick"); //sætter titel
            sherlockHolmes.Harråd(penge, pris); 
            sherlockHolmes.PrintInfo();
            
        }
    }
}
