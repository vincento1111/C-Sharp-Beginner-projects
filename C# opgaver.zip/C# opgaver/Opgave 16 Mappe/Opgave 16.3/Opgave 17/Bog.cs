﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Opgave_16
{
    class Bog
    {
        public bool HarRåd;
        public int pris;
        public string title;
        public int penge;
        public int rest;



        public bool Harråd(int penge, int pris) //tjekker om du har flere penge end bogen koster
        {

            if (penge >= pris)
            {
                
                return HarRåd = true; 
            }

            else
            {
                return HarRåd = false;
            }

        }
        public void SetPenge(int penge)
        {
            this.penge = penge;
        }
        public int GetPenge()
        {
            return penge;
        }

        public void SetPris(int pris)
        {
            this.pris = pris;
        }
        public int GetPris()
        {
            return pris;
        }
        public void SetTitle(string title)
        {
            this.title = title;
        }
        public string GetTitle()
        {
            return title;
        }

        public void PrintInfo()
        {
            Console.WriteLine(title + " - koster " + pris + "Kr.");

           if (HarRåd == true)
            {
                rest = penge - pris;

                Console.WriteLine("Jeg har råd");
            }

            else
            {
                Console.WriteLine("Jeg har desværre ikke råd");
            }
        }


    }
}
