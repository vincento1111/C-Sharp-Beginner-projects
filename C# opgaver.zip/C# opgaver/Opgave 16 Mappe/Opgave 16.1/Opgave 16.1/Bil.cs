﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Opgave_16._1
{
    class Bil
    {
        public void Start()
        {
            Console.WriteLine("Motoren er startet");
        }
        public void Sluk()
        {
            Console.WriteLine("Motoren er slukket");
        }
        public void FillGas(double liters, bool isDiesel)
        {
            Console.WriteLine("Filled tank with: " + liters + " liters ");

            if (isDiesel)
            {
                Console.WriteLine("Diesel");
            }
            else
            {
                Console.WriteLine("Benzin");
            }

        }
        public double RemainingGas()
        {
            return 15.5;
        }
    }
}
