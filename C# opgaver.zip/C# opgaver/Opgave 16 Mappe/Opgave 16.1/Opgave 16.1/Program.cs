﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Opgave_16._1
{
    class Program
    {
        static void Main(string[] args)
        {

            Bil motor = new Bil();
            motor.Start();
            motor.Sluk();
            motor.FillGas(2.5, false);
            double tank = motor.RemainingGas();
            Console.WriteLine(tank);
            Console.WriteLine(motor.RemainingGas());

            Console.ReadKey();

        }
    }
}
