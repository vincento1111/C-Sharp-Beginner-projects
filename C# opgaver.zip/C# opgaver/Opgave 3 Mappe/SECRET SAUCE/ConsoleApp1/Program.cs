﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

using System.IO;
namespace ConsoleApp11
{
    class Program
    {


        static bool FindesNr(string nr)
        {
            String[] linier = File.ReadAllLines("c:\\d46\\person_db.csv");
            foreach (string linje in linier)
            {
                string[] felter = linje.Split(';');
                if (felter[0] == nr)
                {
                    return true;
                }

            }
            return false;
        }

        static void Main(string[] args)
        {
            while (true)
            {
                Console.WriteLine("[O] Opret   [F] Find   [V] Vis alle   [Q] Afslut");

                string[] personInfo = new string[6];
                
                personInfo[0] = "31143143";
                personInfo[1] = "Vincent Schuurhof";
                personInfo[2] = "Adresse";
                personInfo[3] = "2400";
                personInfo[4] = "Byen";
                personInfo[5] = "Vincento2009@hotmail.com";
                

                string command = Console.ReadLine().ToLower();

                if (command == "o" || command == "O")
                {
                    // Brugeren indtaster deres oplysninger
                    Console.Write("Indtast Dit Telefonnummmer: ");
                    string telefon = Console.ReadLine();
                    personInfo[0] = telefon;
                    Console.WriteLine(personInfo[0]);

                    if (FindesNr(telefon))
                    {
                        Console.WriteLine("Nummeret findes allerede...");
                        break;
                    }
                    
                    Console.Write("Indtast Dit Navn: ");
                    string navn = Console.ReadLine();
                    personInfo[1] = navn;
                    Console.WriteLine(personInfo[1]);

                    Console.Write("Indtast Din Adresse: ");
                    string adresse = Console.ReadLine();
                    personInfo[2] = adresse;
                    Console.WriteLine(personInfo[2]);

                    Console.Write("Indtast Dit Post nr: ");
                    string postNr = Console.ReadLine();
                    personInfo[3] = postNr;
                    Console.WriteLine(personInfo[3]);

                    Console.Write("Indtast By: ");
                    string by = Console.ReadLine();
                    personInfo[4] = by;
                    Console.WriteLine(personInfo[4]);

                    Console.Write("Indtast Email: ");
                    string email = Console.ReadLine();
                    personInfo[5] = email;
                    Console.WriteLine(personInfo[5]);



                    String personProfil = String.Join(";", personInfo);



                    File.AppendAllText("c:\\d46\\person_db.csv", "\n" + personProfil);
                    // gemmes i excel fil
                }

                else if (command == "f" || command == "F" )
                {
                    // Finder Nummer
                    String[] linjer = File.ReadAllLines("c:\\d46\\person_db.csv");
                    Console.Write(linjer);

                    Console.WriteLine("Skriv et telefon nr vi skal finde: ");

                    string findTlf = Console.ReadLine();

                   

                    foreach (string linje in linjer)
                    {
                        string[] felter = linje.Split(',');

                        if (felter[0] == findTlf)
                        {
                            foreach (string f in felter)
                            {
                                Console.WriteLine(f);
                            }
                        }
                    }

                

                }



                else if (command == "v" || command == "V")
                {
                    //viser alle data
                    String[] linjer = File.ReadAllLines("c:\\d46\\person_db.csv");
                    Console.Write(linjer);


                    foreach (string linien in linjer)
                    {
                        Console.WriteLine(linien);
                    }
                }
                // Afslutter programmet
                else if (command == "Q" || command == "q")
                {
                    Console.WriteLine("Farvel");
                    break;
                }
                // Hvis brugeren indtaster et ugyldigt input viser programmet en fejlmeddelse
                else
                {
                    Console.WriteLine("Hov det forstod jeg ikke, prøv igen");

                    

                }

            }
            



        }
    }
}