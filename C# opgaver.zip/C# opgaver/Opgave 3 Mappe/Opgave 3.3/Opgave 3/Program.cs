﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Opgave_3
{
    class Program
    {
        static void Main(string[] args)
        {

            string Navn = "Søren";
            int Alder = 16;
            Double Penge = 1234.34;
            Console.WriteLine("Jeg hedder {0}, er {1} år og har tjent {2:c2} på at lappe cykel", Navn,Alder,Penge);

            //2:c2 = penge i kroner. {X] = navn. double = decimaltal
        }
    }
}
