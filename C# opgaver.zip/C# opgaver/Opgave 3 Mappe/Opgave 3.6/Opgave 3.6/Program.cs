﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Opgave_3._6
{
    class Program
    {
        static void Main(string[] args)
        {

            Console.WriteLine("Indtast radius på din cirkel");
            double radius = Convert.ToDouble(Console.ReadLine()); // readline = radius
            Console.WriteLine(Math.PI*Math.Pow(radius,2)); // readline * PI * 2 
        

        }
    }
}
