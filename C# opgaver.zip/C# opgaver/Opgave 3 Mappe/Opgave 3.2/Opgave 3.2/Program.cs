﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Opgave_3._2
{
    class Program
    {
        static void Main(string[] args)
        {
            int tal1 = 5;
            int tal2 = 3;
            Console.WriteLine("tal1 er " + tal1); //Udskriver tekst + int værdi
            Console.WriteLine("tal2 er " + tal2);


        }
    }
}
