﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Opgave_3_7
{
    class Program
    {
        static void Main(string[] args)
        {
            Console.WriteLine("Skriv 3 tal");
            double tal1 = Convert.ToDouble(Console.ReadLine());
            double tal2 = Convert.ToDouble(Console.ReadLine());
            double tal3 = Convert.ToDouble(Console.ReadLine());
            double sum = tal1 + tal2 + tal3;

            Console.WriteLine("Din sum er " + sum);
            double gen = sum / 3;
            Console.WriteLine("Dit gennemsnit er " + gen);

        }
    }
}
