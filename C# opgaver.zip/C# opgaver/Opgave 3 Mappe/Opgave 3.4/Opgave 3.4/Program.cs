﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Opgave_3._4
{
    class Program
    {
        static void Main(string[] args)
        {
            double Kage = 23.56;
            double Øl = 34.67;
            double Pølse = 65.34;
            Console.WriteLine("Øl " + Øl);
            Console.WriteLine("Kage " + Kage);
            Console.WriteLine("Pølse " + Pølse);

            double i_alt = Kage + Øl + Pølse;
            Console.WriteLine("I alt " + i_alt); // I_alt = kagepris ølpris pølsepris
        }
    }
}
