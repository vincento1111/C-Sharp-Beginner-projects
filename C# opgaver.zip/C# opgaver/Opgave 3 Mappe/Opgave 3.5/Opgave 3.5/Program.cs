﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Opgave_3._5
{
    class Program
    {
        static void Main(string[] args)
        {

            string navn = "Vincent";
            int alder = 20;
            Console.WriteLine("Du hedder " + navn + " og er " + alder + " år gammel");


        }
    }
}
