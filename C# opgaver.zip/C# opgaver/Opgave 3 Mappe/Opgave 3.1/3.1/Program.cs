﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace _3._1
{
    class Program
    {
        static void Main(string[] args)
        {
            int tal1 = 5; //Laver en int
            int tal2 = 3;
            Console.WriteLine(tal1); //Udskriver tal
            Console.WriteLine(tal2);
        }
    }
}
