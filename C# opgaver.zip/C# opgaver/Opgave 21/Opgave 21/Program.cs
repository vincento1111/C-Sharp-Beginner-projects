﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Opgave_21
{
    class Program
    {
        static void Main(string[] args)
        {

            int[] numbers = { -2, -1, 0, 10 }; //Laver et array

            int[] numbers2 = new int[4]; //laver et andet array
            numbers2[0] = -2;
            numbers2[1] = -1;
            numbers2[2] = 0;
            numbers2[3] = 10;

            Console.WriteLine(numbers2[1]); 
            Console.WriteLine(numbers2[3]);

            double sum = numbers2[0] + numbers2[1] + numbers2[2] + numbers2[3]; //Regner summen af array
            Console.WriteLine(sum);
        }
    }
}
