﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Opgave_6._1
{
    class Program
    {
        static void Main(string[] args)
        {
            /*
             2 + 1 * 2 = 4
             (2 + 1) * 2 = 6
             5 / 2 = 2,5
             8 % 3 = 2
             1 - 5 = -4
             
             */

            Console.WriteLine(2+1 * 2);
            Console.WriteLine((2+1) * 2);
            Console.WriteLine(5 / 2);
            Console.WriteLine(8 % 3);
            Console.WriteLine(1 - 5);

        }
    }
}
