﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using Microsoft.VisualBasic;
using System.IO;
using System.Xml.Linq;
using System.Xml;



namespace TT_Løsning_v1._1
{

    public partial class Form1 : Form
    {

        double y = 0;
        public Form1()
        {
            InitializeComponent();
        }

        private void textBox1_TextChanged(object sender, EventArgs e)
        {

        }

        private void den_her_rute_Click(object sender, EventArgs e)
        {

            string navn = textBox2.Text; //Her skriver vi personen og hvad han lavede ind i logbogen.

            for (int i = 0; i < 1; i++)
            {
                string s = y.ToString();
                textBox3.Text = s;

                string[] kilometerIdag = new string[1];

                kilometerIdag[0] = s;
                string hour = DateTime.Now.ToString("HH" + ":");
                string minute = DateTime.Now.ToString("mm" + "-" + "\n");
                
                string today = DateTime.Now.ToString("dd" + "-");
                string month = DateTime.Now.ToString("M" + "-");
                string year = DateTime.Now.ToString("yyyy" + "\n");  //Putter tiden lige nu ind i array.

                String personProfil1 = String.Join(";", kilometerIdag);  // samler array ind i en string
                File.AppendAllText("c:\\d46\\kilometer_idag.csv", "\n" + navn + " " + 
                    personProfil1 + " Kilometer den " + hour + minute + today + month + year +"\n"); //Gemmer string ind i csv fil.

                textBox3.Clear();
                
            }

        }

        private void textBox2_TextChanged(object sender, EventArgs e)
        {
            string navn = textBox2.Text;
        }

        private void log_bog_Click(object sender, EventArgs e)
        {


            String[] linier = File.ReadAllLines("c:\\d46\\kilometer_idag.csv");

            string logBog = string.Join(",",
                          linier.Select(x => x.ToString()).ToArray());
            textBox1.Text = logBog;


            //Henter data fra csv putter det i et array og laver array om til string



        }

        private void button1_Click(object sender, EventArgs e)
        {
            textBox1.Clear(); //tømmmer textboxen
        }

        private void label1_Click(object sender, EventArgs e)
        {

        }

        private void textBox3_TextChanged(object sender, EventArgs e)
        {

            string kilometer = textBox3.Text;
            double x = 0;
            double.TryParse(textBox3.Text, out x);

            //udskriv kilometer tal som Double
            //kilometertal skal gemmes som variabel (sum)
            this.y = 0;

            y += x;
            //Lægger X værdi til sum

        }
    }
}
