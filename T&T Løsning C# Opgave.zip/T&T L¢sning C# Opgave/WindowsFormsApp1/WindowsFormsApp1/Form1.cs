﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace WindowsFormsApp1
{
    public partial class TT : Form
    {
        double sum = 0;
        double y = 0;
        public TT()
        {
            InitializeComponent();
        }

        private void Textbox_TextChanged(object sender, EventArgs e)
        {
            string kilometer = Textbox.Text;
            double x = 0;
            double.TryParse(Textbox.Text, out x);
            //udskriv kilometer tal som Double
            //kilometertal skal gemmes som variabel (sum)


            sum += x;
            //Lægger X værdi til sum
            


        }

        private void Kørt_Idag_Click(object sender, EventArgs e)
        {
            string s = sum.ToString();
            Textbox.Text = s;
        }

    }
}
