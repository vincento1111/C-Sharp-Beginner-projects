﻿namespace WindowsFormsApp1
{
    partial class TT
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.Kørt_Idag = new System.Windows.Forms.Button();
            this.Textbox = new System.Windows.Forms.TextBox();
            this.button1 = new System.Windows.Forms.Button();
            this.SuspendLayout();
            // 
            // Kørt_Idag
            // 
            this.Kørt_Idag.Location = new System.Drawing.Point(171, 75);
            this.Kørt_Idag.Name = "Kørt_Idag";
            this.Kørt_Idag.Size = new System.Drawing.Size(110, 23);
            this.Kørt_Idag.TabIndex = 0;
            this.Kørt_Idag.Text = "Kørt idag";
            this.Kørt_Idag.UseVisualStyleBackColor = true;
            this.Kørt_Idag.Click += new System.EventHandler(this.Kørt_Idag_Click);
            // 
            // Textbox
            // 
            this.Textbox.Location = new System.Drawing.Point(54, 12);
            this.Textbox.Name = "Textbox";
            this.Textbox.Size = new System.Drawing.Size(227, 20);
            this.Textbox.TabIndex = 1;
            this.Textbox.TextChanged += new System.EventHandler(this.Textbox_TextChanged);
            // 
            // button1
            // 
            this.button1.Location = new System.Drawing.Point(54, 75);
            this.button1.Name = "button1";
            this.button1.Size = new System.Drawing.Size(111, 23);
            this.button1.TabIndex = 2;
            this.button1.Text = "Kørt Den Her Rute";
            this.button1.UseVisualStyleBackColor = true;
            // 
            // TT
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(331, 309);
            this.Controls.Add(this.button1);
            this.Controls.Add(this.Textbox);
            this.Controls.Add(this.Kørt_Idag);
            this.Name = "TT";
            this.Text = "Form1";
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Button Kørt_Idag;
        private System.Windows.Forms.TextBox Textbox;
        private System.Windows.Forms.Button button1;
    }
}

